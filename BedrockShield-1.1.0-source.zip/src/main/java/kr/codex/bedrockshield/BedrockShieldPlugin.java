package kr.codex.bedrockshield;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class BedrockShieldPlugin extends JavaPlugin {
    private volatile Settings settings;
    private ConnectionDiagnostics diagnostics;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadSettings();

        BedrockDetector detector = new BedrockDetector();
        PlayerStabilizer stabilizer = new PlayerStabilizer(this, detector);
        getServer().getPluginManager().registerEvents(
                new CompatibilityListener(this, detector, stabilizer), this);
        diagnostics = new ConnectionDiagnostics(this, detector);
        getServer().getPluginManager().registerEvents(diagnostics, this);
        diagnostics.enableGeyserHook();
        GeyserConfigRepair configRepair = new GeyserConfigRepair(detector);

        PluginCommand command = getCommand("bedrockshield");
        if (command == null) {
            throw new IllegalStateException("bedrockshield command is missing from plugin.yml");
        }
        BedrockShieldCommand commandHandler = new BedrockShieldCommand(
                this, detector, stabilizer, diagnostics, configRepair);
        command.setExecutor(commandHandler);
        command.setTabCompleter(commandHandler);

        if (!detector.hasProvider()) {
            getLogger().warning("Neither Floodgate nor Geyser-Spigot is enabled. "
                    + "Automatic Bedrock detection will remain inactive.");
        }
        getLogger().info("Enabled with Folia-safe entity scheduling. " + detector.providerSummary());
        diagnostics.doctorLines().stream()
                .filter(line -> line.startsWith("ERROR:"))
                .forEach(line -> getLogger().severe(line));
    }

    @Override
    public void onDisable() {
        if (diagnostics != null) {
            diagnostics.close();
        }
    }

    Settings settings() {
        return settings;
    }

    void reloadSettings() {
        reloadConfig();
        settings = Settings.from(getConfig());
    }
}

