package kr.codex.bedrockshield;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

final class ResyncLimiter {
    private final ConcurrentHashMap<UUID, Long> nextAllowedMillis = new ConcurrentHashMap<>();

    boolean acquire(UUID playerId, long nowMillis, long cooldownMillis) {
        boolean[] acquired = {false};
        nextAllowedMillis.compute(playerId, (ignored, nextAllowed) -> {
            if (nextAllowed == null || nowMillis >= nextAllowed) {
                acquired[0] = true;
                return nowMillis + cooldownMillis;
            }
            return nextAllowed;
        });
        return acquired[0];
    }

    void remove(UUID playerId) {
        nextAllowedMillis.remove(playerId);
    }
}

