package kr.codex.bedrockshield;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class GeyserConfigRepair {
    private static final Pattern SECTION = Pattern.compile("^([A-Za-z0-9_-]+):\\s*(?:#.*)?$");
    private static final Pattern AUTH_TYPE = Pattern.compile("^(\\s+)auth-type:\\s*([^#\\s]+)(\\s*(?:#.*)?)$");
    private static final DateTimeFormatter BACKUP_TIME = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    private final BedrockDetector detector;

    GeyserConfigRepair(BedrockDetector detector) {
        this.detector = detector;
    }

    RepairResult repairFloodgateAuth() {
        if (!detector.geyserEnabled() || !detector.floodgateEnabled()) {
            return RepairResult.failure("Geyser-Spigot과 Floodgate가 모두 활성화되어 있어야 합니다.");
        }
        Optional<Path> optionalConfig = detector.geyserConfigPath();
        if (optionalConfig.isEmpty()) {
            return RepairResult.failure("Geyser config.yml 경로를 API에서 찾지 못했습니다.");
        }

        Path config = optionalConfig.get();
        Path root = config.getParent().toAbsolutePath().normalize();
        if (!config.startsWith(root) || !Files.isRegularFile(config)) {
            return RepairResult.failure("안전한 Geyser config.yml 파일을 찾지 못했습니다: " + config);
        }

        try {
            List<String> original = Files.readAllLines(config, StandardCharsets.UTF_8);
            RewriteResult rewrite = rewriteAuthType(original);
            if (!rewrite.changed()) {
                return RepairResult.success("Geyser auth-type은 이미 floodgate입니다. 파일을 변경하지 않았습니다.", null);
            }

            String timestamp = LocalDateTime.now().format(BACKUP_TIME);
            Path backup = root.resolve("config.yml.bedrockshield-" + timestamp + ".bak").normalize();
            if (!backup.startsWith(root)) {
                return RepairResult.failure("백업 경로 검증에 실패했습니다.");
            }
            Files.copy(config, backup, StandardCopyOption.COPY_ATTRIBUTES);

            Path temporary = Files.createTempFile(root, "config.yml.bedrockshield-", ".tmp");
            try {
                Files.write(temporary, rewrite.lines(), StandardCharsets.UTF_8);
                replaceAtomically(temporary, config);
            } finally {
                Files.deleteIfExists(temporary);
            }
            return RepairResult.success(
                    "Geyser auth-type을 floodgate로 교정했습니다. 서버를 완전히 재시작하세요.", backup);
        } catch (IOException error) {
            return RepairResult.failure("Geyser 설정 교정 실패: " + error.getMessage());
        }
    }

    static RewriteResult rewriteAuthType(List<String> input) {
        List<String> output = new ArrayList<>(input);
        int preferredSection = findSection(output, "java");
        int sectionStart = preferredSection >= 0 ? preferredSection : findSection(output, "remote");
        if (sectionStart < 0) {
            output.add("");
            output.add("java:");
            output.add("  auth-type: floodgate");
            return new RewriteResult(output, true);
        }

        int sectionEnd = findSectionEnd(output, sectionStart);
        for (int index = sectionStart + 1; index < sectionEnd; index++) {
            Matcher matcher = AUTH_TYPE.matcher(output.get(index));
            if (!matcher.matches()) {
                continue;
            }
            if (matcher.group(2).equalsIgnoreCase("floodgate")) {
                return new RewriteResult(output, false);
            }
            output.set(index, matcher.group(1) + "auth-type: floodgate" + matcher.group(3));
            return new RewriteResult(output, true);
        }

        output.add(sectionStart + 1, "  auth-type: floodgate");
        return new RewriteResult(output, true);
    }

    private static int findSection(List<String> lines, String name) {
        for (int index = 0; index < lines.size(); index++) {
            Matcher matcher = SECTION.matcher(lines.get(index));
            if (matcher.matches() && matcher.group(1).equals(name)) {
                return index;
            }
        }
        return -1;
    }

    private static int findSectionEnd(List<String> lines, int sectionStart) {
        for (int index = sectionStart + 1; index < lines.size(); index++) {
            if (SECTION.matcher(lines.get(index)).matches()) {
                return index;
            }
        }
        return lines.size();
    }

    private static void replaceAtomically(Path source, Path target) throws IOException {
        try {
            Files.move(source, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    record RewriteResult(List<String> lines, boolean changed) {
    }

    record RepairResult(boolean success, String message, Path backup) {
        static RepairResult success(String message, Path backup) {
            return new RepairResult(true, message, backup);
        }

        static RepairResult failure(String message) {
            return new RepairResult(false, message, null);
        }
    }
}

