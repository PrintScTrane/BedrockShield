package kr.codex.bedrockshield;

import org.bukkit.Bukkit;
import org.geysermc.floodgate.api.FloodgateApi;
import org.geysermc.geyser.api.GeyserApi;

import java.util.UUID;
import java.nio.file.Path;
import java.util.Optional;

final class BedrockDetector {
    boolean isBedrockPlayer(UUID playerId) {
        return detectedByFloodgate(playerId) || detectedByGeyser(playerId);
    }

    boolean hasProvider() {
        return Bukkit.getPluginManager().isPluginEnabled("floodgate")
                || Bukkit.getPluginManager().isPluginEnabled("Geyser-Spigot");
    }

    String providerSummary() {
        return "Floodgate=" + state(floodgateEnabled())
                + ", Geyser-Spigot=" + state(geyserEnabled())
                + ", ViaVersion=" + state(viaVersionEnabled());
    }

    boolean floodgateEnabled() {
        return Bukkit.getPluginManager().isPluginEnabled("floodgate");
    }

    boolean geyserEnabled() {
        return Bukkit.getPluginManager().isPluginEnabled("Geyser-Spigot");
    }

    boolean viaVersionEnabled() {
        return Bukkit.getPluginManager().isPluginEnabled("ViaVersion");
    }

    String geyserNetworkSummary() {
        if (!geyserEnabled()) {
            return "Geyser is not installed on this backend (it may be on a proxy).";
        }
        try {
            return GeyserBridge.networkSummary();
        } catch (IllegalStateException | LinkageError ignored) {
            return "Geyser API is not ready.";
        }
    }

    Optional<Path> geyserConfigPath() {
        if (!geyserEnabled()) {
            return Optional.empty();
        }
        try {
            return Optional.of(GeyserBridge.configPath());
        } catch (IllegalStateException | LinkageError ignored) {
            return Optional.empty();
        }
    }

    boolean geyserUsesFloodgate() {
        if (!geyserEnabled()) {
            return false;
        }
        try {
            return GeyserBridge.usesFloodgate();
        } catch (IllegalStateException | LinkageError ignored) {
            return false;
        }
    }

    private boolean detectedByFloodgate(UUID playerId) {
        if (!floodgateEnabled()) {
            return false;
        }
        try {
            return FloodgateBridge.isBedrockPlayer(playerId);
        } catch (IllegalStateException | LinkageError ignored) {
            return false;
        }
    }

    private boolean detectedByGeyser(UUID playerId) {
        if (!geyserEnabled()) {
            return false;
        }
        try {
            return GeyserBridge.isBedrockPlayer(playerId);
        } catch (IllegalStateException | LinkageError ignored) {
            return false;
        }
    }

    private String state(boolean enabled) {
        return enabled ? "enabled" : "missing";
    }

    private static final class FloodgateBridge {
        private FloodgateBridge() {
        }

        static boolean isBedrockPlayer(UUID playerId) {
            return FloodgateApi.getInstance().isFloodgatePlayer(playerId);
        }
    }

    private static final class GeyserBridge {
        private GeyserBridge() {
        }

        static boolean isBedrockPlayer(UUID playerId) {
            GeyserApi api = GeyserApi.api();
            return api != null && api.connectionByUuid(playerId) != null;
        }

        static String networkSummary() {
            GeyserApi api = GeyserApi.api();
            if (api == null) {
                return "Geyser API is not ready.";
            }
            String bedrockVersions = api.supportedBedrockVersions().stream()
                    .map(version -> version.versionString())
                    .reduce((left, right) -> left + ", " + right)
                    .orElse("unknown");
            return "Geyser listen=" + api.bedrockListener().address() + ":" + api.bedrockListener().port()
                    + ", auth=" + api.defaultRemoteServer().authType().name().toLowerCase()
                    + ", Java target=" + api.supportedJavaVersion().versionString()
                    + ", Bedrock=" + bedrockVersions;
        }

        static Path configPath() {
            GeyserApi api = GeyserApi.api();
            if (api == null) {
                throw new IllegalStateException("Geyser API is not ready");
            }
            return api.configDirectory().resolve("config.yml").toAbsolutePath().normalize();
        }

        static boolean usesFloodgate() {
            GeyserApi api = GeyserApi.api();
            return api != null && api.defaultRemoteServer().authType()
                    == org.geysermc.geyser.api.network.AuthType.FLOODGATE;
        }
    }
}

