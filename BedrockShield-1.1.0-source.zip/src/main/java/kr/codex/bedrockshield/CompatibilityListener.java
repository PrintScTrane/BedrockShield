package kr.codex.bedrockshield;

import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.Location;
import org.bukkit.block.data.BlockData;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

final class CompatibilityListener implements Listener {
    private final BedrockShieldPlugin plugin;
    private final BedrockDetector detector;
    private final PlayerStabilizer stabilizer;
    private final ResyncLimiter limiter = new ResyncLimiter();
    private final ResyncLimiter blockLimiter = new ResyncLimiter();

    CompatibilityListener(BedrockShieldPlugin plugin, BedrockDetector detector, PlayerStabilizer stabilizer) {
        this.plugin = plugin;
        this.detector = detector;
        this.stabilizer = stabilizer;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        limiter.remove(event.getPlayer().getUniqueId());
        blockLimiter.remove(event.getPlayer().getUniqueId());
        stabilizer.clear(event.getPlayer().getUniqueId());
        stabilizer.schedule(event.getPlayer(), plugin.settings().joinDelayTicks(), false);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
        stabilizer.schedule(event.getPlayer(), plugin.settings().respawnDelayTicks(), false);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        Player player = event.getPlayer();
        if (stabilizer.isInternalTeleport(player.getUniqueId())) {
            return;
        }
        stabilizer.schedule(player, plugin.settings().teleportDelayTicks(), false);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.isCancelled()) {
            requestCancelledRepair(event.getWhoClicked());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.isCancelled()) {
            requestCancelledRepair(event.getWhoClicked());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDrop(PlayerDropItemEvent event) {
        if (event.isCancelled()) {
            requestCancelledRepair(event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        if (event.isCancelled()) {
            requestCancelledRepair(event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onHeldSlot(PlayerItemHeldEvent event) {
        if (event.isCancelled()) {
            requestCancelledRepair(event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockBreak(BlockBreakEvent event) {
        if (event.isCancelled()) {
            requestCancelledBlockRepair(
                    event.getPlayer(),
                    event.getBlock().getLocation(),
                    event.getBlock().getBlockData().clone());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (event.isCancelled()) {
            requestCancelledBlockRepair(
                    event.getPlayer(),
                    event.getBlockPlaced().getLocation(),
                    event.getBlockReplacedState().getBlockData().clone());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        limiter.remove(event.getPlayer().getUniqueId());
        blockLimiter.remove(event.getPlayer().getUniqueId());
        stabilizer.clear(event.getPlayer().getUniqueId());
    }

    private void requestCancelledRepair(HumanEntity human) {
        if (!(human instanceof Player player)) {
            return;
        }
        Settings settings = plugin.settings();
        if (!settings.cancelledInventoryActions()
                || !detector.isBedrockPlayer(player.getUniqueId())
                || !limiter.acquire(player.getUniqueId(), System.currentTimeMillis(), settings.desyncCooldownMillis())) {
            return;
        }

        player.getScheduler().runDelayed(plugin,
                task -> stabilizer.repairInventory(player, true),
                null,
                settings.desyncDelayTicks());
    }

    private void requestCancelledBlockRepair(Player player, Location location, BlockData blockData) {
        Settings settings = plugin.settings();
        if (!settings.cancelledBlockActions()
                || !detector.isBedrockPlayer(player.getUniqueId())
                || !blockLimiter.acquire(player.getUniqueId(), System.currentTimeMillis(), settings.desyncCooldownMillis())) {
            return;
        }

        player.getScheduler().runDelayed(plugin,
                task -> stabilizer.repairBlock(player, location, blockData),
                null,
                settings.desyncDelayTicks());
    }
}

