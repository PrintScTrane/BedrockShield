package kr.codex.bedrockshield;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

class DisconnectClassifierTest {
    @Test
    void identifiesFloodgateKeyErrorsBeforeGenericAuthenticationErrors() {
        String hint = DisconnectClassifier.hint("Please connect through the official Geyser: invalid key");
        assertTrue(hint.contains("key.pem"));
    }

    @Test
    void identifiesProtocolAndXboxErrors() {
        assertTrue(DisconnectClassifier.hint("Outdated server protocol version").contains("ViaVersion"));
        assertTrue(DisconnectClassifier.hint("Xbox authentication failed").contains("Xbox"));
    }
}

