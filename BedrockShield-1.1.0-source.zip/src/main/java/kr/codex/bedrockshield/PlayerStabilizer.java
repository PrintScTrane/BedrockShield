package kr.codex.bedrockshield;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;

final class PlayerStabilizer {
    private static final Set<Material> UNSAFE_SUPPORT = Set.of(
            Material.AIR,
            Material.CAVE_AIR,
            Material.VOID_AIR,
            Material.LAVA,
            Material.FIRE,
            Material.SOUL_FIRE,
            Material.CACTUS,
            Material.MAGMA_BLOCK,
            Material.POWDER_SNOW
    );

    private final BedrockShieldPlugin plugin;
    private final BedrockDetector detector;
    private final Set<UUID> internalTeleports = ConcurrentHashMap.newKeySet();
    private final LongAdder stabilizationRuns = new LongAdder();
    private final LongAdder inventoryRepairs = new LongAdder();
    private final LongAdder blockRepairs = new LongAdder();
    private final LongAdder positionRepairs = new LongAdder();

    PlayerStabilizer(BedrockShieldPlugin plugin, BedrockDetector detector) {
        this.plugin = plugin;
        this.detector = detector;
    }

    void schedule(Player player, long delayTicks, boolean force) {
        player.getScheduler().runDelayed(plugin, task -> stabilize(player, force), null, delayTicks);
    }

    void stabilize(Player player, boolean force) {
        if (!player.isOnline() || (!force && !detector.isBedrockPlayer(player.getUniqueId()))) {
            return;
        }

        stabilizationRuns.increment();
        Settings settings = plugin.settings();
        if (settings.stabilizationInventoryResync()) {
            repairInventory(player, false);
        }
        if (settings.safePositionEnabled()) {
            repairPosition(player, settings);
        }
    }

    void repairInventory(Player player, boolean notify) {
        if (!player.isOnline()) {
            return;
        }
        player.updateInventory();
        inventoryRepairs.increment();
        if (notify && plugin.settings().notifyPlayerAfterRepair()) {
            player.sendMessage(Component.text(plugin.settings().repairMessage(), NamedTextColor.GREEN));
        }
    }

    void repairBlock(Player player, Location location, BlockData blockData) {
        if (!player.isOnline()) {
            return;
        }
        player.sendBlockChange(location, blockData);
        blockRepairs.increment();
    }

    boolean isInternalTeleport(UUID playerId) {
        return internalTeleports.contains(playerId);
    }

    void clear(UUID playerId) {
        internalTeleports.remove(playerId);
    }

    long stabilizationRuns() {
        return stabilizationRuns.sum();
    }

    long inventoryRepairs() {
        return inventoryRepairs.sum();
    }

    long positionRepairs() {
        return positionRepairs.sum();
    }

    long blockRepairs() {
        return blockRepairs.sum();
    }

    private void repairPosition(Player player, Settings settings) {
        if (player.isDead() || player.getGameMode() == GameMode.SPECTATOR || player.isInsideVehicle()
                || player.isSwimming() || player.isGliding() || player.isSleeping()) {
            return;
        }

        Location current = player.getLocation();
        World world = current.getWorld();
        if (settings.rescueBelowWorld()
                && current.getY() < world.getMinHeight() - settings.belowWorldMargin()) {
            teleport(player, world.getSpawnLocation());
            return;
        }

        if (!isEmbedded(current)) {
            return;
        }

        findSafeLocation(current, settings.verticalSearchBlocks()).ifPresent(location -> teleport(player, location));
    }

    private Optional<Location> findSafeLocation(Location origin, int searchBlocks) {
        World world = origin.getWorld();
        int startY = origin.getBlockY();
        for (int offset = 0; offset <= searchBlocks; offset++) {
            int y = startY + offset;
            if (y <= world.getMinHeight() || y + 1 >= world.getMaxHeight()) {
                continue;
            }

            Location candidate = new Location(
                    world,
                    origin.getBlockX() + 0.5,
                    y,
                    origin.getBlockZ() + 0.5,
                    origin.getYaw(),
                    origin.getPitch()
            );
            if (isClear(candidate) && isSafeSupport(candidate.clone().subtract(0, 1, 0).getBlock())) {
                return Optional.of(candidate);
            }
        }
        return Optional.empty();
    }

    private boolean isEmbedded(Location location) {
        return isFullCollisionBlock(location.getBlock())
                || isFullCollisionBlock(location.clone().add(0, 1, 0).getBlock());
    }

    private boolean isClear(Location location) {
        return location.getBlock().isPassable()
                && location.clone().add(0, 1, 0).getBlock().isPassable();
    }

    private boolean isSafeSupport(Block block) {
        Material type = block.getType();
        return !type.isAir() && !UNSAFE_SUPPORT.contains(type) && !block.isPassable();
    }

    private boolean isFullCollisionBlock(Block block) {
        // isOccluding excludes partial blocks such as slabs and stairs. Those can
        // legitimately share the same block coordinate as the player's feet.
        return block.getType().isOccluding() && !block.isPassable();
    }

    private void teleport(Player player, Location target) {
        UUID playerId = player.getUniqueId();
        if (!internalTeleports.add(playerId)) {
            return;
        }
        player.teleportAsync(target, PlayerTeleportEvent.TeleportCause.PLUGIN)
                .whenComplete((success, error) -> {
                    internalTeleports.remove(playerId);
                    if (error != null) {
                        plugin.getLogger().warning("Safe-position repair failed for " + player.getName()
                                + ": " + error.getMessage());
                    } else if (Boolean.TRUE.equals(success)) {
                        positionRepairs.increment();
                    }
                });
    }
}

