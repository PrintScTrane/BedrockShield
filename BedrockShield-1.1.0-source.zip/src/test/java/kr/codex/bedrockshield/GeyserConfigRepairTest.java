package kr.codex.bedrockshield;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class GeyserConfigRepairTest {
    @Test
    void rewritesCurrentJavaSectionWithoutTouchingComments() {
        List<String> input = List.of(
                "bedrock:",
                "  port: 19132",
                "java:",
                "  # Authentication mode",
                "  auth-type: online # keep this comment",
                "advanced:",
                "  debug-mode: false");

        var result = GeyserConfigRepair.rewriteAuthType(input);

        assertTrue(result.changed());
        assertEquals("  auth-type: floodgate # keep this comment", result.lines().get(4));
        assertEquals("  debug-mode: false", result.lines().get(6));
    }

    @Test
    void supportsLegacyRemoteSectionAndDetectsNoOp() {
        var result = GeyserConfigRepair.rewriteAuthType(List.of(
                "remote:",
                "  address: auto",
                "  auth-type: floodgate"));

        assertFalse(result.changed());
    }
}

