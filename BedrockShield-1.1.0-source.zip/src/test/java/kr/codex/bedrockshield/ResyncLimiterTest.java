package kr.codex.bedrockshield;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ResyncLimiterTest {
    @Test
    void rateLimitsEachPlayerIndependently() {
        ResyncLimiter limiter = new ResyncLimiter();
        UUID first = UUID.randomUUID();
        UUID second = UUID.randomUUID();

        assertTrue(limiter.acquire(first, 1_000, 150));
        assertFalse(limiter.acquire(first, 1_149, 150));
        assertTrue(limiter.acquire(first, 1_150, 150));
        assertTrue(limiter.acquire(second, 1_001, 150));
    }

    @Test
    void removalClearsCooldown() {
        ResyncLimiter limiter = new ResyncLimiter();
        UUID player = UUID.randomUUID();

        assertTrue(limiter.acquire(player, 1_000, 150));
        limiter.remove(player);
        assertTrue(limiter.acquire(player, 1_001, 150));
    }
}

