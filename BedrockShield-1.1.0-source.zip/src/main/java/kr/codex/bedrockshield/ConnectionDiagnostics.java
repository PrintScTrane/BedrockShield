package kr.codex.bedrockshield;

import io.papermc.paper.connection.PlayerLoginConnection;
import io.papermc.paper.event.connection.PlayerConnectionValidateLoginEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;
import org.geysermc.geyser.api.GeyserApi;
import org.geysermc.geyser.api.event.EventRegistrar;
import org.geysermc.geyser.api.event.bedrock.SessionDisconnectEvent;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedDeque;

final class ConnectionDiagnostics implements Listener {
    private static final int MAX_FAILURES = 12;
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final BedrockShieldPlugin plugin;
    private final BedrockDetector detector;
    private final ConcurrentLinkedDeque<Failure> failures = new ConcurrentLinkedDeque<>();
    private volatile Runnable geyserUnsubscribe = () -> { };

    ConnectionDiagnostics(BedrockShieldPlugin plugin, BedrockDetector detector) {
        this.plugin = plugin;
        this.detector = detector;
    }

    void enableGeyserHook() {
        if (!detector.geyserEnabled()) {
            return;
        }
        try {
            geyserUnsubscribe = GeyserHook.subscribe(this);
        } catch (IllegalStateException | LinkageError error) {
            plugin.getLogger().warning("Could not attach Geyser disconnect diagnostics: " + error.getMessage());
        }
    }

    void close() {
        try {
            geyserUnsubscribe.run();
        } catch (IllegalStateException | LinkageError ignored) {
            // Geyser may already be shutting down.
        }
    }

    List<String> doctorLines() {
        List<String> lines = new ArrayList<>();
        String serverVersion = Bukkit.getMinecraftVersion();
        lines.add("Server=" + serverVersion + " | " + detector.providerSummary());
        lines.add(detector.geyserNetworkSummary());

        if (detector.geyserEnabled() && detector.floodgateEnabled()) {
            if (detector.geyserUsesFloodgate()) {
                lines.add("OK: Geyser runtime authentication is integrated with Floodgate.");
            } else {
                lines.add("ERROR: Geyser runtime auth is not floodgate. Run /bshield repairauth and restart.");
            }
            var floodgate = Bukkit.getPluginManager().getPlugin("floodgate");
            if (floodgate != null) {
                var key = floodgate.getDataFolder().toPath().resolve("key.pem");
                if (java.nio.file.Files.isRegularFile(key)) {
                    lines.add("OK: Floodgate key.pem exists.");
                } else {
                    lines.add("ERROR: Floodgate key.pem is missing. Restart Floodgate to regenerate it.");
                }
            }
        }

        if (serverVersion.startsWith("26.2") && !detector.viaVersionEnabled()) {
            lines.add("ERROR: Latest Geyser emulates Java 26.3. Install ViaVersion 5.12.2+ on this 26.2 backend.");
        } else if (serverVersion.startsWith("26.2")) {
            lines.add("OK: ViaVersion is present for the Geyser 26.3 -> Folia 26.2 protocol bridge.");
        }

        if (!detector.hasProvider()) {
            lines.add("ERROR: No local Geyser/Floodgate API. Install Floodgate on this backend when Geyser is on a proxy.");
        }
        List<String> conflicting = List.of(
                        "FastLogin", "JPremium", "ProtocolSupport", "ExploitFixer",
                        "SayNoToMcLeaks", "LibHatesMods", "DynamicBungeeAuth").stream()
                .filter(name -> Bukkit.getPluginManager().isPluginEnabled(name))
                .toList();
        if (!conflicting.isEmpty()) {
            lines.add("WARNING: Potential Floodgate login conflicts detected: " + String.join(", ", conflicting));
        }
        lines.add("External checks: the Geyser Bedrock port must allow both TCP and UDP; Xbox/network failures occur before Bukkit login.");
        return lines;
    }

    List<String> recentFailureLines() {
        if (failures.isEmpty()) {
            return List.of("No Bedrock connection failures have been observed since startup.");
        }
        return failures.stream()
                .map(failure -> failure.time() + " " + failure.player() + " [" + failure.stage() + "] " + failure.detail())
                .toList();
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onLogin(PlayerConnectionValidateLoginEvent event) {
        if (event.isAllowed() || !(event.getConnection() instanceof PlayerLoginConnection connection)) {
            return;
        }
        var profile = connection.getAuthenticatedProfile();
        if (profile.getId() == null || !detector.isBedrockPlayer(profile.getId())) {
            return;
        }
        record(profile.getName() == null ? "unknown" : profile.getName(), "Bukkit login",
                plain(event.getKickMessage()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKick(PlayerKickEvent event) {
        if (!detector.isBedrockPlayer(event.getPlayer().getUniqueId())) {
            return;
        }
        record(event.getPlayer().getName(), "Server kick",
                event.getCause().name() + ": " + plain(event.reason()));
    }

    private void recordGeyserDisconnect(String player, String detail) {
        record(player, "Geyser disconnect", detail);
    }

    private void record(String player, String stage, String detail) {
        String sanitized = detail == null ? "unknown" : detail.replace('\n', ' ').replace('\r', ' ').strip();
        if (sanitized.length() > 180) {
            sanitized = sanitized.substring(0, 177) + "...";
        }
        String hint = DisconnectClassifier.hint(sanitized);
        Failure failure = new Failure(LocalTime.now().format(TIME_FORMAT), player, stage,
                sanitized + " | 해결: " + hint);
        failures.addFirst(failure);
        while (failures.size() > MAX_FAILURES) {
            failures.pollLast();
        }
        if (plugin.settings().logConnectionFailures()) {
            plugin.getLogger().warning("Bedrock connection: " + player + " [" + stage + "] " + sanitized);
        }
    }

    private String plain(net.kyori.adventure.text.Component component) {
        return PlainTextComponentSerializer.plainText().serialize(component);
    }

    private record Failure(String time, String player, String stage, String detail) {
    }

    private static final class GeyserHook {
        private GeyserHook() {
        }

        static Runnable subscribe(ConnectionDiagnostics diagnostics) {
            GeyserApi api = GeyserApi.api();
            if (api == null) {
                throw new IllegalStateException("Geyser API is not ready");
            }
            EventRegistrar registrar = EventRegistrar.of(diagnostics);
            api.eventBus().subscribe(registrar, SessionDisconnectEvent.class, event ->
                    diagnostics.recordGeyserDisconnect(
                            event.connection().bedrockUsername(),
                            event.disconnectReason()));
            return () -> {
                GeyserApi current = GeyserApi.api();
                if (current != null) {
                    current.eventBus().unregisterAll(registrar);
                }
            };
        }
    }
}

