package kr.codex.bedrockshield;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class BedrockShieldCommand implements CommandExecutor, TabCompleter {
    private final BedrockShieldPlugin plugin;
    private final BedrockDetector detector;
    private final PlayerStabilizer stabilizer;
    private final ConnectionDiagnostics diagnostics;
    private final GeyserConfigRepair configRepair;

    BedrockShieldCommand(BedrockShieldPlugin plugin, BedrockDetector detector,
                         PlayerStabilizer stabilizer, ConnectionDiagnostics diagnostics,
                         GeyserConfigRepair configRepair) {
        this.plugin = plugin;
        this.detector = detector;
        this.stabilizer = stabilizer;
        this.diagnostics = diagnostics;
        this.configRepair = configRepair;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("bedrockshield.admin")) {
            sender.sendMessage(Component.text("You do not have permission.", NamedTextColor.RED));
            return true;
        }

        String subcommand = args.length == 0 ? "status" : args[0].toLowerCase(Locale.ROOT);
        return switch (subcommand) {
            case "status" -> status(sender);
            case "doctor" -> doctor(sender);
            case "errors" -> errors(sender);
            case "repairauth" -> repairAuth(sender);
            case "reload" -> reload(sender);
            case "fix" -> fix(sender, args);
            default -> {
                sender.sendMessage(Component.text("Usage: /" + label
                                + " <status|doctor|errors|repairauth|reload|fix [player]>",
                        NamedTextColor.YELLOW));
                yield true;
            }
        };
    }

    private boolean status(CommandSender sender) {
        sender.sendMessage(Component.text("BedrockShield " + plugin.getPluginMeta().getVersion(), NamedTextColor.AQUA));
        sender.sendMessage(Component.text(detector.providerSummary(), NamedTextColor.GRAY));
        sender.sendMessage(Component.text(
                "Stabilizations=" + stabilizer.stabilizationRuns()
                        + ", inventory repairs=" + stabilizer.inventoryRepairs()
                        + ", block repairs=" + stabilizer.blockRepairs()
                        + ", position repairs=" + stabilizer.positionRepairs(),
                NamedTextColor.GRAY));
        return true;
    }

    private boolean reload(CommandSender sender) {
        plugin.reloadSettings();
        sender.sendMessage(Component.text("BedrockShield configuration reloaded.", NamedTextColor.GREEN));
        return true;
    }

    private boolean doctor(CommandSender sender) {
        sender.sendMessage(Component.text("Bedrock connection doctor", NamedTextColor.AQUA));
        for (String line : diagnostics.doctorLines()) {
            NamedTextColor color = line.startsWith("ERROR:") ? NamedTextColor.RED
                    : line.startsWith("OK:") ? NamedTextColor.GREEN : NamedTextColor.GRAY;
            sender.sendMessage(Component.text(line, color));
        }
        return true;
    }

    private boolean errors(CommandSender sender) {
        sender.sendMessage(Component.text("Recent Bedrock connection events", NamedTextColor.AQUA));
        diagnostics.recentFailureLines().forEach(line ->
                sender.sendMessage(Component.text(line, NamedTextColor.GRAY)));
        return true;
    }

    private boolean repairAuth(CommandSender sender) {
        GeyserConfigRepair.RepairResult result = configRepair.repairFloodgateAuth();
        sender.sendMessage(Component.text(result.message(),
                result.success() ? NamedTextColor.GREEN : NamedTextColor.RED));
        if (result.backup() != null) {
            sender.sendMessage(Component.text("Backup: " + result.backup(), NamedTextColor.GRAY));
        }
        return true;
    }

    private boolean fix(CommandSender sender, String[] args) {
        Player target;
        if (args.length >= 2) {
            target = Bukkit.getPlayerExact(args[1]);
        } else if (sender instanceof Player player) {
            target = player;
        } else {
            sender.sendMessage(Component.text("Specify an online player.", NamedTextColor.RED));
            return true;
        }

        if (target == null) {
            sender.sendMessage(Component.text("That player is not online.", NamedTextColor.RED));
            return true;
        }
        stabilizer.schedule(target, 1, true);
        sender.sendMessage(Component.text("Scheduled a repair for " + target.getName() + ".", NamedTextColor.GREEN));
        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String alias, @NotNull String[] args) {
        if (!sender.hasPermission("bedrockshield.admin")) {
            return List.of();
        }
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return List.of("status", "doctor", "errors", "repairauth", "reload", "fix").stream()
                    .filter(value -> value.startsWith(prefix)).toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("fix")) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            List<String> matches = new ArrayList<>();
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    matches.add(player.getName());
                }
            }
            return matches;
        }
        return List.of();
    }
}

