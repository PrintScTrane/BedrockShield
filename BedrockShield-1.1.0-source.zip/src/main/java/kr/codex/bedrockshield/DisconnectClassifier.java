package kr.codex.bedrockshield;

import java.util.Locale;

final class DisconnectClassifier {
    private DisconnectClassifier() {
    }

    static String hint(String detail) {
        String value = detail == null ? "" : detail.toLowerCase(Locale.ROOT);
        if (containsAny(value, "invalid key", "official geyser", "aeadbadtagexception", "tag mismatch")) {
            return "Floodgate key.pem 불일치입니다. 같은 서버라면 오래된 Geyser 쪽 키 복사본을 제거하고 재시작하세요.";
        }
        if (containsAny(value, "encryptionrequestpacket", "profile and access token")) {
            return "Geyser/Floodgate 인증 설정 또는 로그인 플러그인 충돌을 확인하세요.";
        }
        if (containsAny(value, "outdated", "incompatible", "version", "protocol")) {
            return "Folia 26.2에는 ViaVersion 5.12.2 이상이 필요합니다.";
        }
        if (containsAny(value, "xbox", "playfab", "microsoft", "terracotta")) {
            return "Xbox 인증 실패입니다. Geyser/Floodgate를 최신화하고 Xbox 서비스 및 클라이언트 로그인을 확인하세요.";
        }
        if (containsAny(value, "timed out", "timeout", "network", "closed by remote")) {
            return "Geyser 포트의 TCP/UDP 개방, 방화벽 및 MTU를 확인하세요.";
        }
        return "서버 콘솔에서 같은 시각의 Geyser/Floodgate 오류를 확인하세요.";
    }

    private static boolean containsAny(String value, String... needles) {
        for (String needle : needles) {
            if (value.contains(needle)) {
                return true;
            }
        }
        return false;
    }
}

