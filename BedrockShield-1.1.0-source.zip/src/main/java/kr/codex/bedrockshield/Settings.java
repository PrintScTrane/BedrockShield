package kr.codex.bedrockshield;

import org.bukkit.configuration.file.FileConfiguration;

record Settings(
        long joinDelayTicks,
        long respawnDelayTicks,
        long teleportDelayTicks,
        boolean stabilizationInventoryResync,
        boolean safePositionEnabled,
        int verticalSearchBlocks,
        boolean rescueBelowWorld,
        int belowWorldMargin,
        boolean cancelledInventoryActions,
        boolean cancelledBlockActions,
        long desyncDelayTicks,
        long desyncCooldownMillis,
        boolean notifyPlayerAfterRepair,
        String repairMessage,
        boolean logConnectionFailures
) {
    static Settings from(FileConfiguration config) {
        return new Settings(
                positive(config.getLong("stabilization.join-delay-ticks", 10), 10),
                positive(config.getLong("stabilization.respawn-delay-ticks", 5), 5),
                positive(config.getLong("stabilization.teleport-delay-ticks", 4), 4),
                config.getBoolean("stabilization.inventory-resync", true),
                config.getBoolean("safe-position.enabled", true),
                bounded(config.getInt("safe-position.vertical-search-blocks", 4), 1, 16),
                config.getBoolean("safe-position.rescue-below-world", true),
                bounded(config.getInt("safe-position.below-world-margin", 8), 1, 64),
                config.getBoolean("desync-repair.cancelled-inventory-actions", true),
                config.getBoolean("desync-repair.cancelled-block-actions", true),
                positive(config.getLong("desync-repair.delay-ticks", 2), 2),
                positive(config.getLong("desync-repair.cooldown-millis", 150), 150),
                config.getBoolean("messages.notify-player-after-repair", false),
                config.getString("messages.repair", "Bedrock client state was resynchronized."),
                config.getBoolean("connection-diagnostics.log-failures", true)
        );
    }

    private static long positive(long value, long fallback) {
        return value >= 1 ? value : fallback;
    }

    private static int bounded(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}

